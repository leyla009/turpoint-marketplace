'use client';

import { useEffect, useState, FormEvent } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ChevronLeft, Minus, Plus, CreditCard, CheckCircle2, Users, Clock, FileDown } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useAuth, useRequireAuth } from '@/app/context/AuthContext';
import { useLanguage } from '@/app/context/LanguageContext';
import PageContainer from '@/app/components/PageContainer';
import GroupInviteCard from '@/app/components/GroupInviteCard';
import { formatAzn, formatDate, isPastDate } from '@/app/lib/format';
import { tourTitle, placeName, titleFromI18n } from '@/app/lib/tourContent';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

export default function BookTour() {
  const { id } = useParams();
  const router = useRouter();
  const { loading: authLoading } = useRequireAuth();
  const { user, token } = useAuth();
  const { t, locale } = useLanguage();

  const [tour, setTour] = useState<any>(null);
  const [group, setGroup] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [seats, setSeats] = useState(1);
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [ticket, setTicket] = useState<any>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [pdfError, setPdfError] = useState('');

  useEffect(() => {
    fetch(`${API_URL}/api/tours/${id}`)
      .then((r) => r.json())
      .then(setTour)
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    // Fixed: this was calling GET /api/group-formations with no tour_id,
    // then treating the response as an array to .find() over. The real
    // endpoint requires tour_id and returns a single group object (or
    // null), never an array - so `group` was silently always null,
    // meaning the "confirmed/forming" banners above and the settled-price
    // preview never activated, even when a real group already existed.
    fetch(`${API_URL}/api/group-formations?tour_id=${id}`)
      .then((r) => (r.ok ? r.json() : null))
      .then(setGroup)
      .catch(() => setGroup(null));
  }, [id]);

  // Price is always the tour's flat listed price - matches bookings.js,
  // which no longer divides a "total group cost" pool by however many
  // people have joined so far (that used to show a solo/early booker the
  // FULL group's cost until enough people joined). min_participants still
  // gates when the group counts as "confirmed" below, it just no longer
  // affects what anyone pays.
  const previewPricePerPerson = tour ? tour.discounted_price ?? tour.price : 0;

  const total = previewPricePerPerson * seats;

  // Card-field helpers: group the number in 4s, and auto-insert the slash in MM/YY.
  const onCardNumber = (v: string) =>
    setCardNumber(v.replace(/\D/g, '').slice(0, 16).replace(/(\d{4})(?=\d)/g, '$1 '));
  const onExpiry = (v: string) => {
    const d = v.replace(/\D/g, '').slice(0, 4);
    setExpiry(d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (!cardNumber) {
      setError(t('booking.pleaseEnterPayment'));
      return;
    }
    if (cardNumber.replace(/\s/g, '').length !== 16 || !/^\d{2}\/\d{2}$/.test(expiry) || !/^\d{3,4}$/.test(cvc)) {
      setError(t('booking.invalidCard'));
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch(`${API_URL}/api/bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          tour_id: Number(id),
          seats,
          payment: { card_number: cardNumber.replace(/\s/g, ''), expiry, cvc },
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(res.status === 402 ? data.error || t('booking.cardDeclined') : data.error || t('booking.bookingFailed'));
        return;
      }
      setTicket(data);
    } catch {
      setError(t('booking.couldntReachBackend'));
    } finally {
      setSubmitting(false);
    }
  };

  if (authLoading || loading) {
    return <div className="p-6 text-sm text-muted-foreground">{t('booking.loading')}</div>;
  }
  if (!tour?.id) {
    return <div className="p-6 text-sm text-muted-foreground">{t('booking.tourNotFound')}</div>;
  }

  if (!ticket && isPastDate(tour.date)) {
    return (
      <PageContainer maxWidth="max-w-2xl">
        <div className="bg-card border border-border rounded-xl p-6 text-center">
          <Clock size={40} className="text-muted-foreground mx-auto mb-3" />
          <h1 className="text-lg font-bold text-foreground mb-1">{tourTitle(tour, locale)}</h1>
          <p className="text-sm text-muted-foreground mb-5">{t('tourDetail.tourEnded')}</p>
          <button
            onClick={() => router.push('/')}
            className="w-full bg-primary text-primary-foreground text-sm font-semibold rounded-lg py-2.5"
          >
            {t('booking.backToTours')}
          </button>
        </div>
      </PageContainer>
    );
  }

  // The PDF endpoint needs the Authorization header, so fetch it as a blob
  // and trigger the download from memory (same approach as the e-ticket page).
  const handleDownloadPdf = async () => {
    setPdfBusy(true);
    setPdfError('');
    try {
      const res = await fetch(`${API_URL}/api/bookings/${ticket.id}/ticket.pdf?lang=${locale}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('pdf');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${ticket.ticket_code}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      setPdfError(t('eTicket.pdfFailed'));
    } finally {
      setPdfBusy(false);
    }
  };

  if (ticket) {
    const isPending = ticket.status === 'pending';
    return (
      <PageContainer maxWidth="max-w-2xl">
        <div className="bg-card border border-border rounded-xl p-6 text-center">
          {isPending ? (
            <Clock size={40} className="text-primary mx-auto mb-3" />
          ) : (
            <CheckCircle2 size={40} className="text-accent mx-auto mb-3" />
          )}
          <h1 className="text-lg font-bold text-foreground mb-1">
            {isPending ? t('booking.seatReserved') : t('booking.bookingConfirmed')}
          </h1>
          <p className="text-sm text-muted-foreground mb-5">
            {isPending ? t('booking.notChargedYet') : t('booking.eTicketBelow')}
          </p>

          <div className="bg-background border border-dashed border-border rounded-lg p-4 text-left space-y-2">
            <div className="flex justify-center pb-2">
              <div className="bg-white p-2 rounded-lg border border-border">
                <QRCodeSVG value={ticket.ticket_code} size={100} />
              </div>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t('booking.ticketCode')}</span>
              <span className="font-mono font-semibold text-primary">{ticket.ticket_code}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t('booking.tour')}</span>
              <span className="font-medium text-foreground">{titleFromI18n(ticket.tour_title, ticket.tour_title_i18n, locale)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t('booking.seats')}</span>
              <span className="font-medium text-foreground">{ticket.seats}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                {isPending ? t('booking.estimatedTotal') : t('booking.totalPaid')}
              </span>
              <span className="font-semibold text-foreground">{formatAzn(ticket.total_price)}</span>
            </div>
            {isPending && (
              <p className="text-[11px] text-muted-foreground pt-2 border-t border-border">
                {t('booking.mayDropFurther')}
              </p>
            )}
          </div>

          <button
            onClick={handleDownloadPdf}
            disabled={pdfBusy}
            className="mt-5 flex items-center justify-center gap-2 w-full bg-primary text-primary-foreground text-sm font-semibold rounded-lg py-2.5 disabled:opacity-60"
          >
            <FileDown size={15} /> {t('eTicket.downloadPdf')}
          </button>
          {pdfError && <p className="text-xs text-red-600 mt-2">{pdfError}</p>}

          <button
            onClick={() => router.push(`/bookings/${ticket.id}`)}
            className="mt-2 w-full bg-card border border-border text-foreground text-sm font-semibold rounded-lg py-2.5 hover:bg-muted transition-colors"
          >
            {t('booking.viewMyBooking')}
          </button>

          <button
            onClick={() => router.push('/')}
            className="mt-2 w-full bg-card border border-border text-foreground text-sm font-semibold rounded-lg py-2.5 hover:bg-muted transition-colors"
          >
            {t('booking.backToTours')}
          </button>
        </div>

        {/* Right after booking is the best moment to recruit friends. */}
        <div className="mt-4 text-left">
          <GroupInviteCard
            tourId={tour.id}
            tourTitle={tourTitle(tour, locale)}
            minParticipants={tour.min_participants}
            maxParticipants={tour.max_participants}
            refreshKey={ticket.id}
          />
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer maxWidth="max-w-2xl">
      <button
        onClick={() => router.back()}
        className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4"
      >
        <ChevronLeft size={16} /> {t('booking.back')}
      </button>

      <h1 className="text-xl font-bold text-foreground mb-1">{tourTitle(tour, locale)}</h1>
      <p className="text-sm text-muted-foreground mb-2">
        {placeName(tour.location, locale)} · {formatDate(tour.date, locale)}
      </p>
      {group && group.status === 'confirmed' && (
        <p className="flex items-center gap-1.5 text-xs font-semibold text-accent mb-4">
          <Users size={13} /> {t('booking.groupConfirmedMsg')}
        </p>
      )}
      {group && (group.status === 'waiting' || group.status === 'forming') && (
        <p className="flex items-center gap-1.5 text-xs font-semibold text-primary mb-4">
          <Users size={13} />{' '}
          {t('booking.groupJoiningMsg', { current: group.current_participants, min: group.min_participants })}
        </p>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between">
          <span className="text-sm font-medium text-foreground">{t('booking.seatsLabel')}</span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setSeats((s) => Math.max(1, s - 1))}
              className="w-7 h-7 rounded-full border border-border flex items-center justify-center text-foreground"
            >
              <Minus size={14} />
            </button>
            <span className="w-5 text-center font-semibold text-foreground">{seats}</span>
            <button
              type="button"
              onClick={() => setSeats((s) => Math.min(tour.max_participants ?? 10, s + 1))}
              className="w-7 h-7 rounded-full border border-border flex items-center justify-center text-foreground"
            >
              <Plus size={14} />
            </button>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-medium text-foreground">{t('booking.bookingAs')}</p>
          <p className="text-sm text-muted-foreground">
            {user?.name} · {user?.email}
          </p>
        </div>

        <div className="bg-card border border-border rounded-xl p-4 space-y-3">
          <p className="text-sm font-medium text-foreground flex items-center gap-1.5">
            <CreditCard size={14} /> {t('booking.paymentSimulated')}
          </p>
          <input
            type="text"
            inputMode="numeric"
            autoComplete="off"
            placeholder={t('booking.cardPlaceholder')}
            value={cardNumber}
            onChange={(e) => onCardNumber(e.target.value)}
            className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background outline-none"
          />
          <div className="grid grid-cols-2 gap-3">
            <input
              type="text"
              inputMode="numeric"
              autoComplete="off"
              placeholder={t('booking.expiryPlaceholder')}
              value={expiry}
              onChange={(e) => onExpiry(e.target.value)}
              className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background outline-none"
            />
            <input
              type="text"
              inputMode="numeric"
              autoComplete="off"
              placeholder={t('booking.cvcPlaceholder')}
              value={cvc}
              onChange={(e) => setCvc(e.target.value.replace(/\D/g, '').slice(0, 4))}
              className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background outline-none"
            />
          </div>
          <p className="text-[11px] text-muted-foreground">{t('booking.testCardHint')}</p>
        </div>

        <div className="bg-card border border-border rounded-xl p-4 space-y-1">
          <p className="text-sm font-medium text-foreground">{t('booking.refundPolicyTitle')}</p>
          <ul className="text-xs text-muted-foreground space-y-0.5 list-disc pl-4">
            <li>{t('booking.refundTier7')}</li>
            <li>{t('booking.refundTier3')}</li>
            <li>{t('booking.refundTier0')}</li>
          </ul>
          <p className="text-[11px] text-muted-foreground pt-1">{t('booking.refundPolicyNote')}</p>
        </div>

        <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 space-y-1">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>
              {formatAzn(previewPricePerPerson)} × {seats}
            </span>
            <span>{formatAzn(total)}</span>
          </div>
          <div className="flex justify-between text-base font-bold text-foreground pt-1 border-t border-border">
            <span>{t('booking.total')}</span>
            <span>{formatAzn(total)}</span>
          </div>
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-primary text-primary-foreground text-sm font-semibold rounded-lg py-3 disabled:opacity-50"
        >
          {submitting
            ? t('booking.processing')
            : group && group.current_participants + seats >= group.min_participants
            ? t('booking.confirmBooking', { total })
            : t('booking.reserveSeat', { total })}
        </button>
      </form>
    </PageContainer>
  );
}