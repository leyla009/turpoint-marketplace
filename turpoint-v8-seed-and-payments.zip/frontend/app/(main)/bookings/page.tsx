'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Clock, CheckCircle2, XCircle, MapPin, Calendar, AlertCircle } from 'lucide-react';
import { useAuth, useRequireAuth } from '@/app/context/AuthContext';
import { useLanguage } from '@/app/context/LanguageContext';
import PageContainer from '@/app/components/PageContainer';
import { formatAzn, formatDate } from '@/app/lib/format';
import { tourTitle, placeName, titleFromI18n } from '@/app/lib/tourContent';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

const STATUS_STYLE: Record<string, { Icon: any; className: string; labelKey: 'status.pending' | 'status.confirmed' | 'status.cancelled' }> = {
  pending: { Icon: Clock, className: 'text-primary bg-primary/10', labelKey: 'status.pending' },
  confirmed: { Icon: CheckCircle2, className: 'text-accent bg-accent/10', labelKey: 'status.confirmed' },
  cancelled: { Icon: XCircle, className: 'text-muted-foreground bg-muted', labelKey: 'status.cancelled' },
};

export default function MyBookingsPage() {
  const router = useRouter();
  const { loading: authLoading } = useRequireAuth();
  const { token } = useAuth();
  const { t, locale } = useLanguage();

  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!token) return;
    setError(false);
    fetch(`${API_URL}/api/bookings/my-trips`, { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => {
        if (!r.ok) throw new Error('request failed');
        return r.json();
      })
      .then(setBookings)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [token]);

  if (authLoading || loading) {
    return <div className="p-6 text-sm text-muted-foreground">{t('dashboard.loading')}</div>;
  }

  return (
    <PageContainer maxWidth="max-w-2xl">
      <h1 className="font-display text-xl font-bold text-foreground mb-1">{t('myBookings.title')}</h1>
      <p className="text-sm text-muted-foreground mb-5">{t('myBookings.subtitle')}</p>

      {error ? (
        <div className="bg-card border border-dashed border-border rounded-xl p-6 text-center">
          <AlertCircle size={22} className="text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">{t('myBookings.couldntLoad')}</p>
        </div>
      ) : bookings.length === 0 ? (
        <div className="bg-card border border-dashed border-border rounded-xl p-6 text-center">
          <p className="text-sm text-muted-foreground mb-3">{t('myBookings.notBookedYet')}</p>
          <button onClick={() => router.push('/')} className="text-sm text-primary font-semibold">
            {t('myBookings.browseTours')}
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          {bookings.map((b) => {
            const style = STATUS_STYLE[b.status] ?? STATUS_STYLE.confirmed;
            const StatusIcon = style.Icon;
            return (
              <Link
                key={b.id}
                href={`/bookings/${b.id}`}
                className="block bg-card border border-border rounded-xl p-3 hover:border-primary/40 transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{titleFromI18n(b.tour_title, b.tour_title_i18n, locale)}</p>
                    <p className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                      <MapPin size={11} /> {b.tour_location}
                      <span className="mx-1">·</span>
                      <Calendar size={11} /> {formatDate(b.tour_date, locale)}
                    </p>
                  </div>
                  <span
                    className={`flex items-center gap-1 text-[10px] font-semibold px-2 py-1 rounded-full shrink-0 ${style.className}`}
                  >
                    <StatusIcon size={10} /> {t(style.labelKey)}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-border text-xs">
                  <span className="font-mono text-muted-foreground">{b.ticket_code}</span>
                  <span className="text-muted-foreground">
                    {t('myBookings.seatsCount', { count: b.seats })} ·{' '}
                    <span className="font-semibold text-foreground">{formatAzn(b.total_price)}</span>
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </PageContainer>
  );
}