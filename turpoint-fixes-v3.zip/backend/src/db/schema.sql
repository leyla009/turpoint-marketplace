-- TurPoint database schema
-- Task 1: run via `node src/db/index.js` to create all tables.
 
CREATE TABLE IF NOT EXISTS operators (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id),   -- owning account; null for demo/seed operators
  name TEXT NOT NULL,
  description TEXT,
  languages TEXT,             -- comma-separated, e.g. "az,en,ru"
  photo_url TEXT,
  vehicle_features TEXT,      -- e.g. "wifi,ac,charging,luggage"
  phone TEXT,                 -- always starts with +994
  phone_verified INTEGER DEFAULT 0,
  phone_verification_code TEXT,          -- pending code from POST /me/phone/send-code
  phone_verification_phone TEXT,         -- the number that code was issued for
  phone_verification_expires_at TEXT,
  instagram TEXT,             -- handle, without the leading @
  rating REAL DEFAULT 0,
  completed_tours_count INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
 
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  id_number TEXT,             -- saved ID card (FIN) number, so bookings don't require retyping it
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
 
CREATE TABLE IF NOT EXISTS tours (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  operator_id INTEGER NOT NULL REFERENCES operators(id),
  title TEXT NOT NULL,
  description TEXT,
  location TEXT,
  category TEXT,              -- nature, history, entertainment, ...
  route TEXT,
  price REAL NOT NULL,
  date TEXT NOT NULL,
  duration_days INTEGER DEFAULT 1,
  min_participants INTEGER DEFAULT 1,
  max_participants INTEGER DEFAULT 10,
  interest_score TEXT,        -- JSON: {"nature":0.8,"history":0.2}
  features TEXT,               -- comma-separated slugs: breakfast,evening_tea,guide,road_games,hotel_stay
  vehicle_features TEXT,       -- comma-separated slugs: ac,wifi,luggage,charging - set per tour, not per operator
  photo_url TEXT,
  click_count INTEGER DEFAULT 0,   -- bumped every time GET /api/tours/:id is viewed - feeds "Populyar turlar"
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS group_formations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tour_id INTEGER NOT NULL REFERENCES tours(id),
  total_cost REAL NOT NULL,
  min_participants INTEGER NOT NULL,
  current_participants INTEGER DEFAULT 0,
  price_per_person REAL,
  status TEXT DEFAULT 'waiting',   -- waiting | forming | confirmed | cancelled
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
 
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tour_id INTEGER NOT NULL REFERENCES tours(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  group_formation_id INTEGER REFERENCES group_formations(id),
  seats INTEGER DEFAULT 1,
  total_price REAL NOT NULL,
  status TEXT DEFAULT 'confirmed', -- pending | confirmed | cancelled (pending = group hasn't reached its minimum yet)
  ticket_code TEXT UNIQUE,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
 
CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tour_id INTEGER NOT NULL REFERENCES tours(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
 
CREATE TABLE IF NOT EXISTS last_minute_deals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tour_id INTEGER NOT NULL REFERENCES tours(id),
  discount_percent REAL NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Traveler-saved tours ("Sevimlilər" in the account menu, and the heart
-- icon on tour cards) - a plain many-to-many with no extra state per save.
CREATE TABLE IF NOT EXISTS favorites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  tour_id INTEGER NOT NULL REFERENCES tours(id),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, tour_id)
);

-- Smart Planner itineraries a traveler chose to keep. trip_json is the
-- whole validated planner response (trip summary, days, activities with
-- real tour ids) stored as-is - simplest thing that works for "show me my
-- saved trips again later" without inventing a second normalized schema
-- for what's fundamentally a snapshot of an AI-assisted plan.
CREATE TABLE IF NOT EXISTS saved_trips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  trip_json TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Sprint 3: indexes for the query patterns the routes actually use (search
-- filters, ownership lookups, and the per-tour joins on bookings/reviews/
-- deals/group_formations). IF NOT EXISTS makes these safe to re-run on
-- every boot, same pattern as the tables above.
CREATE INDEX IF NOT EXISTS idx_tours_location ON tours(location);
CREATE INDEX IF NOT EXISTS idx_tours_category ON tours(category);
CREATE INDEX IF NOT EXISTS idx_tours_date ON tours(date);
CREATE INDEX IF NOT EXISTS idx_tours_operator_id ON tours(operator_id);

CREATE INDEX IF NOT EXISTS idx_bookings_user_id ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_tour_id ON bookings(tour_id);
CREATE INDEX IF NOT EXISTS idx_bookings_group_formation_id ON bookings(group_formation_id);

CREATE INDEX IF NOT EXISTS idx_reviews_tour_id ON reviews(tour_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user_id ON reviews(user_id);

CREATE INDEX IF NOT EXISTS idx_group_formations_tour_id ON group_formations(tour_id);

CREATE INDEX IF NOT EXISTS idx_deals_tour_id ON last_minute_deals(tour_id);
CREATE INDEX IF NOT EXISTS idx_deals_expires_at ON last_minute_deals(expires_at);

CREATE INDEX IF NOT EXISTS idx_favorites_user_id ON favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_favorites_tour_id ON favorites(tour_id);

CREATE INDEX IF NOT EXISTS idx_saved_trips_user_id ON saved_trips(user_id);
 
