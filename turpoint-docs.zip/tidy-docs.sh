#!/usr/bin/env bash
# Run from anywhere inside the repo, AFTER unzipping this package over the project root.
# Moves the design reference into docs/ and removes the old planning/changelog files
# (their useful content now lives in README.md and docs/).
set -e
cd "$(git rev-parse --show-toplevel)"

git mv DESIGN.md docs/design.md
git rm -q --ignore-unmatch DEPLOYMENT.md TASKS.md CHANGES*.md

echo
echo "Done. Review with:  git status"
echo "Then commit on a branch:  git add -A && git commit -m 'docs: consolidate README and docs/'"
